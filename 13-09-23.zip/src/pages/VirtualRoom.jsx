import React from 'react'

function VirtualRoom() {
  return (
    <div>VirtualRoom</div>
  )
}

export default VirtualRoom